from PIL import Image
import torch
from torchvision.models import mobilenet_v2, MobileNet_V2_Weights
import time

device = torch.device("cpu")
weigths = MobileNet_V2_Weights.DEFAULT

model = mobilenet_v2(weights=weigths).to(device)

model.eval()

image = Image.open("../../C04/C04_data/images/cat.jpg").convert("RGB")

input_batch = (
    weigths.transforms()(image)
           .unsqueeze(0)
           .to(device)
)

print("==== Warm-up =====")
for i in range(10):
    start = time.perf_counter()
    with torch.inference_mode():
        _ = model(input_batch)

    end = time.perf_counter()
    latency_ms = (end - start) * 1000

    print(f"{i+ 1: 2d}회: {latency_ms:.3f}ms")
